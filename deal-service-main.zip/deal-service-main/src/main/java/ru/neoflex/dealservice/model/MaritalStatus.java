package ru.neoflex.dealservice.model;

public enum MaritalStatus {
    MARRIED,
    SINGLE,
    DIVORCED,
    WIDOW_WIDOWER
}

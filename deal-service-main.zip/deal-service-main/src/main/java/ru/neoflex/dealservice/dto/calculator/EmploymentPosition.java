package ru.neoflex.dealservice.dto.calculator;

public enum EmploymentPosition {
    LOW,
    MEDIUM,
    HIGH
}

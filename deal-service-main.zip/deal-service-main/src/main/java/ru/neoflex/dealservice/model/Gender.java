package ru.neoflex.dealservice.model;

public enum Gender {
    MALE,
    FEMALE,
    NO_BINARY
}
